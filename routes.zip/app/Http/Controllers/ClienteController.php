<?php

namespace App\Http\Controllers;

use App\Http\Resources\Cliente as ResourcesCliente;
use App\Models\Cliente;
use App\Models\Endereco;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
}
